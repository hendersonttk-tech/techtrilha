// Conteúdo das trilhas. Dados puros: sem DOM, sem efeitos colaterais.
export const LEVELS = {
ini:{n:"Iniciante",c:"var(--g1)",d:"Os primeiros passos: entenda como o mundo digital funciona.",items:[
["O que é um computador?","Hardware é a parte física; software são os programas que rodam nela.",["CPU: o 'cérebro' que executa instruções","Memória RAM: espaço de trabalho temporário","Armazenamento (SSD/HD): onde os arquivos ficam guardados","Placa-mãe: conecta todas as peças"]],
["Como a internet funciona","Uma rede global de computadores conectados que trocam informações.",["Seu dispositivo pede uma página a um servidor","O endereço (domínio) é traduzido em IP pelo DNS","O navegador recebe e mostra o conteúdo","Wi-Fi é só o jeito de chegar ao roteador, não a internet em si"]],
["Sistemas operacionais","O software que gerencia o aparelho e permite usar outros programas.",["Windows, macOS e Linux no computador","Android e iOS no celular","Ele controla arquivos, memória e dispositivos conectados"]],
["Segurança básica","Hábitos simples que evitam a maioria dos golpes.",["Use senhas longas e diferentes em cada site","Ative a verificação em duas etapas (2FA)","Desconfie de links e anexos inesperados (phishing)","Mantenha o sistema e os apps atualizados","Use um gerenciador de senhas"]],
["O que é a nuvem","Usar computadores de outra empresa pela internet em vez do seu.",["Google Drive, iCloud e OneDrive guardam arquivos online","Você acessa de qualquer aparelho","Vantagem: backup e compartilhamento fáceis"]],
["Inteligência artificial sem mistério","Programas que aprendem padrões a partir de muitos exemplos.",["Assistentes como o Claude geram texto e ajudam em tarefas","Recomendações de vídeo e música também usam IA","A IA pode errar: sempre confira informações importantes"]]]},
int:{n:"Intermediário",c:"var(--g2)",d:"Hora de colocar a mão na massa e entender como as coisas são construídas.",items:[
["Lógica de programação","A base de qualquer linguagem: pensar em passos claros.",["Variáveis guardam valores","Condicionais (if/else) tomam decisões","Laços (for/while) repetem tarefas","Funções reaproveitam código"]],
["HTML, CSS e JavaScript","O trio que constrói quase todo site.",["HTML: estrutura e conteúdo","CSS: aparência e layout","JavaScript: interatividade","Dica: crie uma página pessoal como primeiro projeto"]],
["Git e GitHub","Controle de versão: o histórico de tudo que você muda no código.",["git init, add, commit: salvar versões","branch: testar ideias sem quebrar o principal","GitHub: guarda o código online e facilita trabalho em equipe"]],
["Redes: IP, DNS e HTTP","Como os dispositivos se encontram e conversam.",["IPv4 e IPv6 identificam dispositivos","DNS traduz nomes em endereços","HTTP/HTTPS é o protocolo da web; o 'S' indica criptografia","Códigos comuns: 200 (ok), 404 (não encontrado), 500 (erro no servidor)"]],
["Bancos de dados e SQL","Onde os sistemas guardam informações de forma organizada.",["Tabelas com linhas e colunas","SELECT, INSERT, UPDATE e DELETE","Chave primária identifica cada registro","NoSQL (ex.: MongoDB) guarda documentos flexíveis"]],
["APIs","Contratos que permitem que programas conversem entre si.",["REST usa URLs e métodos GET, POST, PUT, DELETE","Os dados costumam vir em JSON","Chaves de API autenticam quem está pedindo","Exemplo: app de clima consultando um serviço de previsão"]]]},
ava:{n:"Avançado",c:"var(--g3)",d:"Conceitos de quem projeta sistemas robustos e escaláveis.",items:[
["Estruturas de dados e complexidade","Escolher a estrutura certa muda o desempenho radicalmente.",["Arrays, listas ligadas, pilhas, filas","Tabelas hash: busca média em O(1)","Árvores e grafos para hierarquias e redes","Notação Big-O mede como o custo cresce com a entrada"]],
["Arquitetura de sistemas","Como organizar software grande para evoluir sem dor.",["Monólito vs microsserviços","Filas de mensagens (Kafka, RabbitMQ) desacoplam serviços","Cache (Redis) reduz latência","Balanceadores de carga distribuem o tráfego"]],
["Containers e Kubernetes","Empacotar e orquestrar aplicações de forma previsível.",["Docker isola app e dependências em um container","Kubernetes gerencia muitos containers automaticamente","CI/CD automatiza testes e deploys","Infraestrutura como código (Terraform)"]],
["Machine learning e LLMs","Modelos que aprendem com dados e geram resultados.",["Treinamento ajusta milhões ou bilhões de parâmetros","Redes neurais e o mecanismo de atenção (transformers)","Embeddings representam significado como números","RAG une um modelo a uma base de conhecimento","Avaliar vieses e alucinações é essencial"]],
["Criptografia","A matemática por trás da privacidade na internet.",["Simétrica (AES): mesma chave para cifrar e decifrar","Assimétrica (RSA, curvas elípticas): par de chaves pública e privada","Hash (SHA-256) gera uma 'impressão digital' dos dados","Certificados TLS garantem que o site é quem diz ser"]],
["Sistemas distribuídos","Muitos computadores trabalhando como um só, e falhando às vezes.",["Teorema CAP: consistência, disponibilidade e tolerância a partições","Replicação e sharding escalam bancos de dados","Consenso (Raft, Paxos) mantém nós de acordo","Projete sempre pensando que tudo pode falhar"]]]}
};

export const TABS = [
  ["home", "Início"],
  ["ini", "Iniciante"],
  ["int", "Intermediário"],
  ["ava", "Avançado"],
];

export const TRAIL_KEYS = ["ini", "int", "ava"];

export const totalItems = () =>
  TRAIL_KEYS.reduce((n, k) => n + LEVELS[k].items.length, 0);
