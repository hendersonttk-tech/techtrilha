// Camada pura: recebe dados, devolve strings HTML. Sem DOM, sem efeitos colaterais.
import { LEVELS, TRAIL_KEYS, totalItems } from "./content.js";

export const esc = (s) =>
  String(s).replace(
    /[&<>"']/g,
    (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[c],
  );

const sk = (cls = "") => `<span class="sk ${cls}" aria-hidden="true"></span>`;

export function renderHome() {
  const cards = TRAIL_KEYS.map(
    (k, i) =>
      `<a class="card lvl rv" href="#${k}" style="--c:${esc(LEVELS[k].c)};--i:${i + 2}" data-testid="card-${k}">` +
      `<div class="tag">Pasta</div><h3>${esc(LEVELS[k].n)}</h3><p>${esc(LEVELS[k].d)}</p></a>`,
  ).join("");
  return (
    `<section class="hero"><h1 class="rv" style="--i:0">Aprenda tecnologia do zero ao avançado.</h1>` +
    `<p class="rv" style="--i:1">Três trilhas com conteúdos práticos e diretos: comece pelo básico, evolua para o intermediário e mergulhe em temas avançados.</p>` +
    `<a class="btn rv" style="--i:2" href="#ini">Começar pelo iniciante →</a></section>` +
    `<div class="grid">${cards}</div>` +
    `<div class="stats rv" style="--i:5"><div><b>${TRAIL_KEYS.length}</b>trilhas</div>` +
    `<div><b>${totalItems()}</b>conteúdos</div><div><b>100%</b>gratuito</div></div>`
  );
}

// O corpo de cada item é "hidratado" sob demanda (lazy) em renderItemBody.
export function renderTrail(k) {
  const l = LEVELS[k];
  const items = l.items
    .map(
      (it, i) =>
        `<details class="rv" style="--i:${i + 2}" data-k="${esc(k)}" data-i="${i}">` +
        `<summary>${esc(it[0])}</summary><div class="body"></div></details>`,
    )
    .join("");
  return (
    `<div class="tag rv" style="--c:${esc(l.c)};--i:0">Trilha</div>` +
    `<h2 class="rv" style="--i:1">${esc(l.n)}</h2><p class="sub rv" style="--i:1">${esc(l.d)}</p>` +
    items
  );
}

export function renderItemBody(k, i) {
  const it = LEVELS[k]?.items[i];
  if (!it) return "";
  return `<p>${esc(it[1])}</p><ul>${it[2].map((t) => `<li>${esc(t)}</li>`).join("")}</ul>`;
}

export function renderSkeleton(k) {
  if (k === "home") {
    return (
      `<section class="hero">${sk("h1")}${sk("h1 s")}${sk("line")}${sk("line s")}${sk("btn-sk")}</section>` +
      `<div class="grid">${[0, 1, 2].map(() => `<div class="card">${sk("tagl")}${sk("h3l")}${sk("line")}${sk("line s")}</div>`).join("")}</div>`
    );
  }
  const n = LEVELS[k]?.items.length ?? 6;
  return (
    `${sk("tagl")}${sk("h2l")}${sk("line")}` +
    Array.from({ length: n }, () => `<div class="sk-row">${sk("line")}</div>`).join("")
  );
}
