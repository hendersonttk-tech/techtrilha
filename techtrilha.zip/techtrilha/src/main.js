import { TABS } from "./content.js";
import { createProgressBar, prefersReducedMotion, revealOnScroll, toggleDetails, wait } from "./motion.js";
import { captureError, initTelemetry, metric, track } from "./telemetry.js";
import { renderHome, renderItemBody, renderSkeleton, renderTrail } from "./views.js";

const nav = document.getElementById("nav");
const app = document.getElementById("app");
const progress = createProgressBar(document.getElementById("bar"));
const validKeys = TABS.map((t) => t[0]);
let token = 0;

for (const [key, label] of TABS) {
  const a = document.createElement("a");
  a.href = `#${key}`;
  a.textContent = label;
  a.dataset.key = key;
  nav.appendChild(a);
}

const keyFromHash = () => {
  const h = location.hash.slice(1);
  return validKeys.includes(h) ? h : "home";
};

async function go(k, first = false) {
  const t = ++token;
  const started = performance.now();
  for (const a of nav.children) {
    const on = a.dataset.key === k;
    a.classList.toggle("on", on);
    if (on) a.setAttribute("aria-current", "page");
    else a.removeAttribute("aria-current");
  }
  progress.start();
  const rm = prefersReducedMotion();
  try {
    if (!first) {
      app.classList.add("out"); // animação de saída
      await wait(rm ? 0 : 140);
      if (t !== token) return;
    }
    app.setAttribute("aria-busy", "true");
    app.innerHTML = `<div class="skeleton">${renderSkeleton(k)}</div>`; // estado de carregamento
    app.classList.remove("out");
    scrollTo(0, 0);
    await wait(rm ? 0 : 320);
    if (t !== token) return;
    app.innerHTML = k === "home" ? renderHome() : renderTrail(k); // entrada
    app.removeAttribute("aria-busy");
    revealOnScroll(app);
    track("view", { page: k });
    metric("route_render_ms", Math.round(performance.now() - started), { page: k });
  } catch (err) {
    captureError(err, { page: k });
    app.innerHTML = `<p class="err" role="alert">Não foi possível carregar esta página. <a href="#${k}">Tentar de novo</a></p>`;
    app.removeAttribute("aria-busy");
  } finally {
    if (t === token) progress.done();
  }
}

// Lazy: o corpo de cada item só é montado na primeira abertura.
const hydrate = (d, body) => {
  if (body.dataset.ready) return;
  body.innerHTML = renderItemBody(d.dataset.k, Number(d.dataset.i));
  body.dataset.ready = "1";
};

app.addEventListener("click", (e) => {
  const s = e.target.closest("summary");
  if (!s) return;
  e.preventDefault();
  const d = s.parentElement;
  toggleDetails(d, hydrate);
  track("toggle_item", { trail: d.dataset.k, index: Number(d.dataset.i) });
});

window.addEventListener("hashchange", () => go(keyFromHash()));
initTelemetry();
go(keyFromHash(), true);
