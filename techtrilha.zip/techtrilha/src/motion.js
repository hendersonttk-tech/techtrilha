// Utilitários de movimento. Toda animação respeita prefers-reduced-motion.
export const prefersReducedMotion = () =>
  typeof matchMedia === "function" && matchMedia("(prefers-reduced-motion: reduce)").matches;

export const wait = (ms) => new Promise((r) => setTimeout(r, ms));

export function createProgressBar(el) {
  let timer;
  const set = (p) => {
    el.style.transform = `scaleX(${p})`;
  };
  return {
    start() {
      clearInterval(timer);
      el.style.opacity = "1";
      let p = 0.08;
      set(p);
      timer = setInterval(() => {
        p += (0.9 - p) * 0.15;
        set(p);
      }, 80);
    },
    done() {
      clearInterval(timer);
      set(1);
      setTimeout(() => {
        el.style.opacity = "0";
        set(0);
      }, 250);
    },
  };
}

// Entrada em cascata conforme os elementos entram na tela (lazy reveal).
export function revealOnScroll(root) {
  const els = [...root.querySelectorAll(".rv")];
  if (!("IntersectionObserver" in window) || prefersReducedMotion()) {
    for (const e of els) e.classList.add("vis");
    return;
  }
  const io = new IntersectionObserver(
    (entries) => {
      for (const e of entries) {
        if (e.isIntersecting) {
          e.target.classList.add("vis");
          io.unobserve(e.target);
        }
      }
    },
    { rootMargin: "0px 0px -8% 0px" },
  );
  for (const e of els) io.observe(e);
}

// Abre/fecha <details> com altura animada.
export function toggleDetails(d, hydrate) {
  const body = d.querySelector(".body");
  if (body.getAnimations().length) return;
  if (!d.open) hydrate(d, body);
  if (prefersReducedMotion()) {
    d.open = !d.open;
    return;
  }
  if (d.open) {
    const h = body.offsetHeight;
    const a = body.animate(
      [
        { height: `${h}px`, opacity: 1 },
        { height: "0px", opacity: 0 },
      ],
      { duration: 200, easing: "ease-in" },
    );
    a.onfinish = () => {
      d.open = false;
    };
  } else {
    d.open = true;
    const h = body.offsetHeight;
    body.animate(
      [
        { height: "0px", opacity: 0 },
        { height: `${h}px`, opacity: 1 },
      ],
      { duration: 260, easing: "cubic-bezier(.2,.8,.2,1)" },
    );
  }
}
