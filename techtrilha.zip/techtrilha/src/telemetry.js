// Camada de observabilidade neutra de fornecedor.
// Sentry / Datadog / New Relic / OpenTelemetry entram como "adapters" (ver docs/OBSERVABILITY.md).
const adapters = [];

export function registerAdapter(adapter) {
  adapters.push(adapter);
}

export function clearAdapters() {
  adapters.length = 0;
}

function emit(method, ...args) {
  for (const a of adapters) {
    try {
      a[method]?.(...args);
    } catch {
      // Telemetria nunca pode quebrar o app.
    }
  }
}

export const captureError = (error, context = {}) => emit("captureError", error, context);
export const track = (name, props = {}) => emit("track", name, props);
export const metric = (name, value, props = {}) => emit("metric", name, value, props);

export function initTelemetry() {
  window.addEventListener("error", (e) =>
    captureError(e.error ?? new Error(e.message), { source: "window.error" }),
  );
  window.addEventListener("unhandledrejection", (e) =>
    captureError(e.reason instanceof Error ? e.reason : new Error(String(e.reason)), {
      source: "unhandledrejection",
    }),
  );
  if ("PerformanceObserver" in window) {
    for (const type of ["largest-contentful-paint", "layout-shift"]) {
      try {
        new PerformanceObserver((list) => {
          for (const entry of list.getEntries()) {
            metric(type, entry.value ?? entry.startTime);
          }
        }).observe({ type, buffered: true });
      } catch {
        // Tipo não suportado neste navegador.
      }
    }
  }
}
