// "Architecture contract": regras de dependência entre camadas. Quebrou a regra, o CI falha.
module.exports = {
  forbidden: [
    { name: "no-circular", severity: "error", comment: "Sem dependências circulares.", from: {}, to: { circular: true } },
    {
      name: "pure-layer-stays-pure",
      severity: "error",
      comment: "content.js e views.js são puros: não podem importar DOM/efeitos (motion, telemetry, main).",
      from: { path: "^src/(content|views)\\.js$" },
      to: { path: "^src/(motion|telemetry|main)\\.js$" },
    },
    {
      name: "main-is-entry-only",
      severity: "error",
      comment: "Só o ponto de entrada compõe as camadas; ninguém importa main.js.",
      from: { pathNot: "^src/main\\.js$" },
      to: { path: "^src/main\\.js$" },
    },
    {
      name: "src-never-imports-tests",
      severity: "error",
      from: { path: "^src/" },
      to: { path: "^tests/" },
    },
  ],
  options: { doNotFollow: { path: "node_modules" }, includeOnly: "^(src|tests)" },
};
