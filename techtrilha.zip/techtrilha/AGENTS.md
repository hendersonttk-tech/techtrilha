# AGENTS.md — regras do projeto TechTrilha

Este arquivo vale para **qualquer agente ou pessoa**, de qualquer modelo (Claude, GPT, Gemini, Copilot…).
Leia inteiro antes de mexer no código. `CLAUDE.md` apenas aponta para cá.

## 1. Fluxo obrigatório: Issue → Branch → PR → Deploy

Toda tarefa, sem exceção, é uma **Correção**, **Melhoria** ou **Nova função**.

1. **Crie a Issue primeiro** (template em `.github/ISSUE_TEMPLATE/`), com label `correção`, `melhoria` ou `nova-função` e critérios de aceite verificáveis.
   - CLI: `gh issue create --title "[Melhoria] ..." --label melhoria --body-file ...`
2. **Branch a partir de `main`**: `tipo/NN-slug`, com `fix/`, `improve/` ou `feat/`. Ex.: `feat/12-modo-escuro`.
3. **Commits** em Conventional Commits, citando a Issue: `feat(trilhas): adiciona busca (#12)`.
4. **Abra um PR** usando `.github/PULL_REQUEST_TEMPLATE.md`. A descrição **deve mencionar a Issue** (`Closes #12`, `Fixes #12` ou `Refs #12`). O workflow `PR rules` bloqueia o PR sem isso.
5. **Nunca faça push direto na `main`.** Todo deploy acontece por merge de PR (squash) → workflow `Deploy` publica no GitHub Pages.
6. O PR só é mergeado com CI verde: lint, knip, arquitetura, commitlint, testes unitários, e2e.

Não encontrou Issue para o que vai fazer? Crie antes de escrever código.

## 2. Definition of Done de UI

Toda interface nova ou alterada precisa de:

- **Skeleton** para o estado de carregamento (`renderSkeleton` em `src/views.js`), invisível a leitores de tela (`aria-hidden`).
- **Animação de entrada, saída e progresso**: entrada em cascata (`.rv` + `--i`), saída em troca de rota (`main.out`), barra de progresso (`#bar`).
- **Lazy loading**: conteúdo pesado só é montado quando necessário (ex.: corpo dos itens na 1ª abertura; imagens com `loading="lazy"`).
- **`prefers-reduced-motion` respeitado**: sem animação, o conteúdo continua visível e utilizável.
- Princípios de movimento: duração curta (140–400 ms), easing de desaceleração na entrada e aceleração na saída, animar só `opacity`/`transform`/altura, nada que bloqueie interação. Veja `docs/MOTION.md`.

## 3. Arquitetura (contrato verificado por `npm run arch`)

```
index.html → src/main.js (única camada que compõe as outras)
src/content.js   dados puros
src/views.js     HTML como string, puro (sem DOM)
src/motion.js    animações/DOM
src/telemetry.js observabilidade neutra (adapters)
```
- `content.js` e `views.js` **não** importam `motion`, `telemetry` nem `main`.
- Ninguém importa `main.js`. `src/` não importa `tests/`. Sem dependência circular.
- Sem build step: o site é estático (ES modules). Não adicione bundler sem Issue aprovada.

## 4. Qualidade

| Ferramenta | Comando | Papel |
|---|---|---|
| Biome | `npm run lint` / `npm run format` | lint + formatação |
| Knip | `npm run knip` | código/dependências não usados |
| dependency-cruiser | `npm run arch` | contrato de arquitetura |
| Commitlint + Husky | automático no commit | Conventional Commits |
| Vitest + Codecov | `npm test` | unitários e cobertura (mín. 80% linhas) |
| Playwright | `npm run test:e2e` | ponta a ponta (desktop + mobile) |
| Stryker | `npm run mutation` | testes de mutação (semanal no CI) |

Atalho local antes de abrir PR: `npm run check && npm run test:e2e`.
Código em `views.js`/`telemetry.js` sem teste não é aceito. Código de DOM (`main.js`, `motion.js`) é coberto por e2e.

## 5. Observabilidade

- Nunca chame SDK de fornecedor direto no código da aplicação. Use `captureError`, `track` e `metric` de `src/telemetry.js`.
- Sentry, Datadog, New Relic e OpenTelemetry entram como **adapters** (`registerAdapter`). Veja `docs/OBSERVABILITY.md`.
- Telemetria nunca pode quebrar o app (já protegido em `emit`) e não pode enviar dados pessoais.

## 6. Manutenção deste arquivo

Mudou o processo, uma ferramenta ou a arquitetura? Atualize este arquivo **no mesmo PR**.
