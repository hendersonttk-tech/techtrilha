# TechTrilha 🚀

Site estático para aprender tecnologia (3 trilhas, 18 conteúdos). Regras de trabalho: **[AGENTS.md](AGENTS.md)**.

## Rodar
```bash
npm install
npm run dev          # http://localhost:4173
npm run check        # lint + knip + arquitetura + unitários
npm run test:e2e     # Playwright (rode `npx playwright install chromium` antes)
```

## Primeiro envio ao GitHub
```bash
git init -b main
git add index.html && git commit -m "chore: baseline do site original"   # use seu index.html original
git remote add origin git@github.com:SEU_USUARIO/techtrilha.git && git push -u origin main

bash scripts/create-issues.sh                      # cria labels + Issues #1–#9
git switch -c improve/1-modularizacao-e-qualidade
# copie o restante do projeto, depois:
git add -A && git commit -m "feat: modulariza, adiciona motion, testes, CI e observabilidade (#1)"
git push -u origin HEAD
gh pr create --fill --body "Closes #1, closes #2, closes #3, closes #5, closes #6, closes #7, closes #8. Refs #4, #9"
```
Depois: Settings → Pages → Source "GitHub Actions"; Settings → Branches → proteger `main` exigindo os checks; secret `CODECOV_TOKEN`.
