## Resumo
<!-- O que muda e por quê, em 1–3 frases. -->

## Issue
<!-- OBRIGATÓRIO. Use Closes/Fixes/Resolves para fechar, ou Refs para só referenciar. -->
Closes #

## Tipo
- [ ] Correção
- [ ] Melhoria
- [ ] Nova função

## Checklist (Definition of Done)
- [ ] Skeleton / estado de carregamento em toda UI nova
- [ ] Animação de entrada, saída e progresso; respeita `prefers-reduced-motion`
- [ ] Conteúdo pesado carregado sob demanda (lazy)
- [ ] Testes unitários e/ou e2e adicionados ou atualizados
- [ ] Eventos/erros relevantes passam por `src/telemetry.js`
- [ ] `npm run check` e `npm run test:e2e` passam localmente
- [ ] Commits no padrão Conventional Commits
