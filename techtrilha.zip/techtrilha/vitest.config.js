import { defineConfig } from "vitest/config";

export default defineConfig({
  test: {
    environment: "node",
    include: ["tests/unit/**/*.test.js"],
    coverage: {
      provider: "v8",
      reporter: ["text", "lcov"],
      include: ["src/**/*.js"],
      // main.js e motion.js dependem do navegador: cobertos pelos testes e2e.
      exclude: ["src/main.js", "src/motion.js"],
      thresholds: { lines: 80, functions: 80, branches: 70, statements: 80 },
    },
  },
});
