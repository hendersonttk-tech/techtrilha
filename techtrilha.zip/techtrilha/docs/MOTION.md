# Movimento no TechTrilha

Referência pedida para o projeto: skill **Motion Principles** (`github.com/kylezantos/design-principles`).
> Status: o conteúdo dessa skill **não pôde ser lido** durante a primeira implementação (sem acesso à internet). Os princípios abaixo são práticas gerais de movimento. A Issue "Auditar movimento com a skill Motion Principles" cobre a revisão contra a skill original.

## O que está implementado
| Momento | Implementação | Onde |
|---|---|---|
| Carregamento | Skeleton com shimmer por rota | `renderSkeleton`, `.sk` |
| Progresso | Barra no topo durante a troca de página | `createProgressBar`, `#bar` |
| Saída | Fade + leve subida (140 ms, ease-in) | `main.out` |
| Entrada | Cascata `opacity`+`translateY` (400 ms, ease-out) ao entrar no viewport | `.rv`, `revealOnScroll` |
| Abrir/fechar item | Altura animada (260 ms abre / 200 ms fecha) | `toggleDetails` |
| Feedback de toque | `scale(.96–.97)` em abas e botões | `nav a:active`, `.btn:active` |
| Lazy | Corpo do item montado na 1ª abertura | `hydrate` em `main.js` |
| Acessibilidade | `prefers-reduced-motion`, `aria-busy`, `aria-current` | CSS + `main.js` |

## Regras
- Só `opacity`, `transform` e altura. Nada de animar `top/left/width`.
- Entrada desacelera (`cubic-bezier(.2,.8,.2,1)`), saída é mais rápida que a entrada.
- Atraso em cascata limitado a 8 passos (`min(var(--i),8)`), para listas longas não demorarem.
- Nada de animação que bloqueie clique: o conteúdo é clicável assim que aparece.
- O skeleton dura ~320 ms porque o conteúdo hoje é local. Se virar busca remota, o tempo passa a ser o real e o mínimo deve cair.
