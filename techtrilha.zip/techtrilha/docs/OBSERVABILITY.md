# Observabilidade

O app emite sinais por `src/telemetry.js`: `captureError`, `track`, `metric`. Hoje já emite:
- erros não tratados (`window.error`, `unhandledrejection`) e falhas de renderização
- `view` (página vista), `toggle_item`
- `route_render_ms`, LCP e CLS (via `PerformanceObserver`)

Sem adapter registrado, nada é enviado. Cada fornecedor é um adapter com a forma:
```js
registerAdapter({
  captureError(error, ctx) {},
  track(name, props) {},
  metric(name, value, props) {},
});
```

## Ativar cada fornecedor (cada um exige conta/chave sua)
| Fornecedor | O que cobre | Como ligar |
|---|---|---|
| **Sentry** | erros, performance, replay | `Sentry.init({ dsn })` e adapter chamando `Sentry.captureException` / `addBreadcrumb` |
| **Datadog RUM** | sessões reais, Web Vitals | `datadogRum.init({ applicationId, clientToken, site })` e `addAction` / `addError` |
| **New Relic Browser** | SPA/page views, erros | snippet do browser agent; `newrelic.noticeError` / `addPageAction` |
| **OpenTelemetry** | traces/métricas padronizados | `@opentelemetry/sdk-trace-web` + exporter OTLP para seu coletor |

Chaves públicas de navegador (DSN, clientToken) podem ficar no HTML; **nunca** coloque chaves privadas no repositório. Para um site estático, normalmente escolha 1 ou 2 destes (por exemplo Sentry para erros + OTel para métricas), já que os quatro coletam sinais sobrepostos.
