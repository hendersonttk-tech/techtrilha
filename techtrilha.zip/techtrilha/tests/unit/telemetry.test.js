import { afterEach, describe, expect, it, vi } from "vitest";
import { captureError, clearAdapters, metric, registerAdapter, track } from "../../src/telemetry.js";

afterEach(() => clearAdapters());

describe("telemetry", () => {
  it("encaminha eventos para todos os adapters", () => {
    const a = { track: vi.fn(), captureError: vi.fn(), metric: vi.fn() };
    const b = { track: vi.fn() };
    registerAdapter(a);
    registerAdapter(b);
    track("view", { page: "ini" });
    captureError(new Error("x"), { page: "ini" });
    metric("lcp", 1200, { page: "home" });
    expect(a.track).toHaveBeenCalledWith("view", { page: "ini" });
    expect(b.track).toHaveBeenCalledWith("view", { page: "ini" });
    expect(a.captureError).toHaveBeenCalledOnce();
    expect(a.metric).toHaveBeenCalledWith("lcp", 1200, { page: "home" });
  });
  it("um adapter com falha não afeta os outros", () => {
    const bad = {
      track: () => {
        throw new Error("boom");
      },
    };
    const good = { track: vi.fn() };
    registerAdapter(bad);
    registerAdapter(good);
    expect(() => track("view")).not.toThrow();
    expect(good.track).toHaveBeenCalledOnce();
  });
  it("ignora adapters sem o método chamado", () => {
    registerAdapter({});
    expect(() => metric("x", 1)).not.toThrow();
  });
});
