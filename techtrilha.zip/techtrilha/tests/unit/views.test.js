import { describe, expect, it } from "vitest";
import { LEVELS, TABS, TRAIL_KEYS, totalItems } from "../../src/content.js";
import { esc, renderHome, renderItemBody, renderSkeleton, renderTrail } from "../../src/views.js";

describe("content", () => {
  it("tem 3 trilhas e 18 conteúdos", () => {
    expect(TRAIL_KEYS).toHaveLength(3);
    expect(totalItems()).toBe(18);
  });
  it("toda aba aponta para uma trilha ou para home", () => {
    for (const [key] of TABS) expect(key === "home" || LEVELS[key]).toBeTruthy();
  });
  it("todo item tem título, resumo e tópicos", () => {
    for (const k of TRAIL_KEYS)
      for (const [title, summary, topics] of LEVELS[k].items) {
        expect(title).toBeTruthy();
        expect(summary).toBeTruthy();
        expect(topics.length).toBeGreaterThan(0);
      }
  });
});

describe("esc", () => {
  it("escapa caracteres perigosos", () => {
    expect(esc(`<a href="x">'&'</a>`)).toBe("&lt;a href=&quot;x&quot;&gt;&#39;&amp;&#39;&lt;/a&gt;");
  });
});

describe("renderHome", () => {
  const html = renderHome();
  it("deriva a contagem de conteúdos dos dados", () => {
    expect(html).toContain("<b>18</b>conteúdos");
    expect(html).toContain("<b>3</b>trilhas");
  });
  it("renderiza um link por trilha", () => {
    for (const k of TRAIL_KEYS) expect(html).toContain(`href="#${k}"`);
  });
  it("marca elementos para animação de entrada", () => {
    expect(html).toContain('class="card lvl rv"');
  });
});

describe("renderTrail / renderItemBody (lazy)", () => {
  it("não inclui o corpo dos itens até serem abertos", () => {
    const html = renderTrail("ini");
    expect(html).toContain("O que é um computador?");
    expect(html).not.toContain("Hardware é a parte física");
    expect((html.match(/<details/g) ?? []).length).toBe(LEVELS.ini.items.length);
  });
  it("monta o corpo sob demanda", () => {
    expect(renderItemBody("ini", 0)).toContain("Hardware é a parte física");
    expect(renderItemBody("ini", 0)).toContain("<li>");
  });
  it("devolve vazio para item inexistente", () => {
    expect(renderItemBody("ini", 999)).toBe("");
    expect(renderItemBody("nope", 0)).toBe("");
  });
});

describe("renderSkeleton", () => {
  it("existe skeleton para home e para cada trilha", () => {
    expect(renderSkeleton("home")).toContain('class="sk');
    for (const k of TRAIL_KEYS) {
      const rows = renderSkeleton(k).match(/class="sk-row"/g) ?? [];
      expect(rows).toHaveLength(LEVELS[k].items.length);
    }
  });
  it("é invisível para leitores de tela", () => {
    expect(renderSkeleton("home")).toContain('aria-hidden="true"');
  });
});
