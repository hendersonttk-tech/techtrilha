import { expect, test } from "@playwright/test";

test("home mostra skeleton e depois o conteúdo", async ({ page }) => {
  await page.goto("/");
  await expect(page.locator("#app .skeleton")).toBeVisible();
  await expect(page.getByRole("heading", { level: 1 })).toContainText("Aprenda tecnologia");
  await expect(page.locator("#app .skeleton")).toHaveCount(0);
  await expect(page.getByText("18conteúdos")).toBeVisible();
});

test("navega para uma trilha e abre um item (lazy)", async ({ page }) => {
  await page.goto("/#ini");
  const item = page.locator("details", { hasText: "O que é um computador?" });
  await expect(item).toBeVisible();
  await expect(item.locator(".body")).toBeEmpty();
  await item.locator("summary").click();
  await expect(item.getByText("Hardware é a parte física")).toBeVisible();
  await item.locator("summary").click();
  await expect(item).not.toHaveAttribute("open", "");
});

test("navegação por abas atualiza hash e aria-current", async ({ page }) => {
  await page.goto("/");
  await page.getByRole("link", { name: "Avançado" }).click();
  await expect(page).toHaveURL(/#ava$/);
  await expect(page.getByRole("heading", { level: 2 })).toHaveText("Avançado");
  await expect(page.getByRole("link", { name: "Avançado" })).toHaveAttribute("aria-current", "page");
});

test("hash inválido cai na home", async ({ page }) => {
  await page.goto("/#nada");
  await expect(page.getByRole("heading", { level: 1 })).toBeVisible();
});

test.describe("prefers-reduced-motion", () => {
  test.use({ reducedMotion: "reduce" });
  test("conteúdo aparece sem depender de animação", async ({ page }) => {
    await page.goto("/#int");
    await expect(page.locator("details").first()).toBeVisible();
    await expect(page.locator("details").first()).toHaveCSS("opacity", "1");
  });
});

test("não há erros de console", async ({ page }) => {
  const errors = [];
  page.on("pageerror", (e) => errors.push(e.message));
  page.on("console", (m) => m.type() === "error" && errors.push(m.text()));
  await page.goto("/");
  await page.getByRole("link", { name: "Intermediário" }).click();
  await expect(page.getByRole("heading", { level: 2 })).toHaveText("Intermediário");
  expect(errors).toEqual([]);
});
