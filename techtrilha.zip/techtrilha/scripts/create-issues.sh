#!/usr/bin/env bash
# Cria labels e Issues do backlog inicial. Requer: gh auth login e estar dentro do repositório.
set -euo pipefail

gh label create "correção"   --color d73a4a --description "Algo quebrado" 2>/dev/null || true
gh label create "melhoria"   --color a2eeef --description "Melhorar o que existe" 2>/dev/null || true
gh label create "nova-função" --color 0e8a16 --description "Capacidade nova" 2>/dev/null || true

gh issue create --title "[Melhoria] Modularizar o site em src/ (ES modules)" --label "melhoria" --body-file docs/issues/01.md
gh issue create --title "[Correção] Contagem de conteúdos fixa e cards não acessíveis" --label "correção" --body-file docs/issues/02.md
gh issue create --title "[Melhoria] Skeleton, lazy loading e animações em toda a interface" --label "melhoria" --body-file docs/issues/03.md
gh issue create --title "[Nova função] Camada de observabilidade (Sentry, Datadog, New Relic, OpenTelemetry)" --label "nova-função" --body-file docs/issues/04.md
gh issue create --title "[Melhoria] Qualidade de código: Biome, Commitlint, Knip, contrato de arquitetura e Stryker" --label "melhoria" --body-file docs/issues/05.md
gh issue create --title "[Nova função] Testes unitários, e2e e cobertura (Vitest, Playwright, Codecov)" --label "nova-função" --body-file docs/issues/06.md
gh issue create --title "[Melhoria] CI/CD por Pull Request com deploy no GitHub Pages" --label "melhoria" --body-file docs/issues/07.md
gh issue create --title "[Melhoria] Documentar o processo para agentes (AGENTS.md)" --label "melhoria" --body-file docs/issues/08.md
gh issue create --title "[Melhoria] Auditar movimento com a skill Motion Principles (kylezantos/design-principles)" --label "melhoria" --body-file docs/issues/09.md
